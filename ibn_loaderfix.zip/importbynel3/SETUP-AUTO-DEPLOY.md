# 🚀 How to Set Up Auto-Deploy (Never Upload to Netlify Again!)

Once this is set up, any change you make → GitHub → Netlify auto-updates in **30 seconds**.

---

## Step 1 — Create a Free GitHub Account
1. Go to **github.com**
2. Click **Sign up**
3. Use your **new Gmail** you mentioned
4. Verify your email

---

## Step 2 — Create a Repository (Your Website's Home)
1. After logging in, click the **+** button at the top right
2. Click **New repository**
3. Name it: `import-by-nel`
4. Make sure it says **Public**
5. Click **Create repository**

---

## Step 3 — Upload Your Website Files to GitHub
1. On the new repository page, click **uploading an existing file**
2. Drag ALL files from the `importbynel3` folder:
   - `index.html`
   - `admin.html`
   - `manifest.json`
   - `logo.svg`
   - `icon.svg`
3. Scroll down, click **Commit changes**

---

## Step 4 — Create a FREE New Netlify Account
1. Go to **netlify.com**
2. Click **Sign up** → use your **new Gmail**
3. This gives you fresh 300 credits!

---

## Step 5 — Connect Netlify to GitHub (The Magic Step!)
1. In Netlify dashboard, click **Add new site**
2. Click **Import an existing project**
3. Click **GitHub**
4. Authorise Netlify to access GitHub
5. Select your `import-by-nel` repository
6. Leave all settings as default
7. Click **Deploy site**

✅ Your site is now live with a Netlify link!

---

## Step 6 — How to Update Your Site Going Forward
Whenever you want to make changes:
1. Go to **github.com** → your repository
2. Click on the file you want to change (e.g. `index.html`)
3. Click the **pencil icon** (Edit)
4. Make your changes
5. Click **Commit changes**

→ Netlify will automatically detect the change and **redeploy in 30 seconds!**

No more dragging files. No more 300 credit limit issues. ✅

---

## 💡 Even Better — Use GitHub Desktop App
Download **GitHub Desktop** (free) from desktop.github.com
- This lets you edit files on your computer and push changes with one click
- Much easier than editing in the browser

---

## Need Help?
Tell me when you've created the GitHub account and I'll walk you through each step! 😊
